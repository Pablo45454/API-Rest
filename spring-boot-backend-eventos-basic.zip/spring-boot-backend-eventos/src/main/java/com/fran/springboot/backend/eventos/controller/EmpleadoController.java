package com.fran.springboot.backend.eventos.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.fran.springboot.backend.eventos.entidades.Empleado;
import com.fran.springboot.backend.eventos.service.IEmpleadoService;

@RestController
public class EmpleadoController {
	
	@Autowired
	private IEmpleadoService service;
	
	@GetMapping("/api/empleados")
	public List<Empleado> listar() {
	    return service.listar();
	}
}
