package com.fran.springboot.backend.eventos.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.fran.springboot.backend.eventos.entidades.Valoracion;
import com.fran.springboot.backend.eventos.service.IValoracionService;

@RestController
public class ValoracionController {
	
	@Autowired
	private IValoracionService service;
	
	@GetMapping("/api/valoraciones")
	public List<Valoracion> listar() {
	    return service.listar();
	}

}
