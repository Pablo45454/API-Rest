package com.fran.springboot.backend.eventos.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.fran.springboot.backend.eventos.entidades.Foto;
import com.fran.springboot.backend.eventos.service.IFotoService;

@RestController
public class FotoController {
	
	@Autowired
	private IFotoService service;
	
	@GetMapping("/api/fotos")
	public List<Foto> listar() {
	    return service.listar();
	}
}
