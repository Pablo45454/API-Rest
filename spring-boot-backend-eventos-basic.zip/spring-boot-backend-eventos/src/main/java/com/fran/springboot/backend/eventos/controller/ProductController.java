package com.fran.springboot.backend.eventos.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.fran.springboot.backend.eventos.entidades.Product;
import com.fran.springboot.backend.eventos.service.IProductService;

@RestController
public class ProductController {
	@Autowired
	private IProductService service;
	
	@GetMapping("/api/productos")
	public List<Product> listar() {
	    return service.listar();
	}
	
	/*@GetMapping("/api/productos/{id}")
	public Product listarPorId(@PathVariable("id") Integer id) {
		return service.listarPorId(id);
	}*/
}
