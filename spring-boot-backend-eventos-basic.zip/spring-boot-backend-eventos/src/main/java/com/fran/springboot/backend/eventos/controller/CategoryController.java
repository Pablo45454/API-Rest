package com.fran.springboot.backend.eventos.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.fran.springboot.backend.eventos.entidades.Category;

import com.fran.springboot.backend.eventos.service.ICategoryService;

@RestController
public class CategoryController {
	
	@Autowired
	private ICategoryService service;
	
	@GetMapping("/api/categorias")
	public List<Category> listar() {
	    return service.listar();
	}
}
