package com.fran.springboot.backend.eventos;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootBackendEventosApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootBackendEventosApplication.class, args);
	}

}
