package com.fran.springboot.backend.eventos;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootBackendEventosApplicationTests {

	@Test
	void contextLoads() {
	}

}
